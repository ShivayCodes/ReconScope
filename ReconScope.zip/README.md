# ReconScope

ReconScope is a cross-platform, non-root bug hunting and OSINT tool written in Python and Bash. It runs on Android (Termux), Windows, macOS, and Linux.

## 🔧 Features
- Email and domain reconnaissance
- DNS & WHOIS lookup
- JSON output support
- Verbose and debug modes

## ⚙️ Installation
```bash
git clone https://github.com/yourname/ReconScope.git
cd ReconScope
bash install.sh
```

## ▶️ Usage
```bash
python3 python/main.py -d example.com --json -v --debug
```

## 📁 Output
- Saves structured output in `outputs/` as `.json` files.

## 🚀 Roadmap
- Subdomain brute-forcing
- JS endpoint extraction
- Passive DNS, IP ASN info

## ✉️ Contribution
PRs are welcome! Please open issues for suggestions.

## © License
[MIT License](LICENSE)
