import requests

def email_hunter(domain, verbose=False):
    url = f"https://crt.sh/?q=%25.{domain}&output=json"
    if verbose:
        print(f"[~] Fetching: {url}")
    response = requests.get(url)
    data = []

    if response.ok:
        for item in response.json():
            result = {"name_value": item.get("name_value")}
            data.append(result)
            if verbose:
                print(f"[~] Found: {result['name_value']}")
    else:
        print("[!] Failed to fetch data")

    return {"module": "email_hunter", "domain": domain, "results": data}
