import argparse
import json
import traceback
from osint.email_hunter import email_hunter
from utils.output_saver import save_output

def main():
    parser = argparse.ArgumentParser(description="ReconScope - OSINT & Recon Tool")
    parser.add_argument("-d", "--domain", help="Target domain")
    parser.add_argument("--json", help="Output JSON to file", action="store_true")
    parser.add_argument("-v", "--verbose", help="Verbose output", action="store_true")
    parser.add_argument("--debug", help="Enable debug mode", action="store_true")

    args = parser.parse_args()

    if not args.domain:
        print("[-] Domain is required. Use -d example.com")
        return

    try:
        if args.verbose:
            print(f"[+] Starting scan for: {args.domain}")

        results = email_hunter(args.domain, verbose=args.verbose)

        if args.json:
            save_output(results, args.domain)

        if args.verbose:
            print("[+] Done.")

    except Exception as e:
        print(f"[!] Error: {e}")
        if args.debug:
            traceback.print_exc()

if __name__ == "__main__":
    main()
