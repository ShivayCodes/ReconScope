import json
import os

def save_output(data, domain):
    os.makedirs("outputs", exist_ok=True)
    filepath = f"outputs/{domain}_output.json"
    with open(filepath, "w") as f:
        json.dump(data, f, indent=4)
    print(f"[+] Output saved to {filepath}")
