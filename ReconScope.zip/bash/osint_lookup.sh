#!/bin/bash

echo "[*] WHOIS Lookup for $1"
whois $1

echo "[*] DNS Records for $1"
dig $1 any +short
