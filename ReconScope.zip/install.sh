#!/bin/bash

echo "[*] Installing dependencies..."
pkg install -y python git curl grep sed jq whois
pip install -r requirements.txt
